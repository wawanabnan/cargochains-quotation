# 📌 Ringkasan Proyek CargoChains – Modul Sales / Quotation Freight

## ✅ Kondisi saat ini
- **Framework**: Django 5.x  
- **Apps utama**:  
  - `partners` → tabel `partners_partner` (flags: `is_customer`, `is_vendor`, `is_agent`, + `created_at`/`updated_at`).  
  - `sales` → sedang dibangun ulang (SO nanti; fokus sekarang **quotation freight**).

## ✅ Quotation Freight
- **Model utama**:
  - `Quotation`: auto-number (`QYYMM-####`), default currency **IDR**, fields: `transport_mode`, `service_option`, `multi_destination`, `origin`, `destination`, `notes`, `date`, `validity_date`, `customer`.
  - `Cargo`: description, qty, weight_kg, volume_cbm, origin, destination.
  - `CargoCharge`: description, qty, rate, amount (unik per cargo).
- **Relasi**:
  - `Quotation` 1–N `Cargo`
  - `Cargo` 1–N `CargoCharge`

## ✅ Workflow Wizard (Freight)
- **Step 0 (Start)**: pilih Business Type (Freight/Ship Charter), `transport_mode`, `service_option`, dan **Multi Destination**.
- **Step 1 (Header)**:
  - Jika **multi-destination = False** → Origin/Destination di **Header** (dan disembunyikan di Cargo).
  - Jika **multi-destination = True** → Origin/Destination diisi **per Cargo** (field O/D Header dikosongkan).
- **Step 2 (Cargos)**:
  - Input cargo lines. Untuk single-destination, O/D cargo mengikuti header otomatis.

## ✅ Tampilan
- Full width (wide), flat (tanpa rounded/shadow).
- **List**: `quotation_list.html` (tombol “+ New Quotation”).
- **Wizard**: `quotation_freight_start.html` (Step 0), `quotation_freight.html` (Step 1 & 2).
- **Detail**: `quotation_detail.html`
  - Header quotation (Mode, Service, Currency, Multi-destination, O/D Header jika single).
  - Untuk tiap Cargo:
    - Judul cargo; jika **multi-destination** → tampilkan **Origin → Destination** di bawah judul.
    - **Cargo detail** tabel horizontal (Qty / Weight / Volume).
    - **Line Charges** tabel terpisah di bawahnya; subtotal per cargo & **Grand Total** di akhir.
- **PDF Export**: Summary (per cargo) & Detail (per charge).

## ✅ Data Sample
- Fixture partner: `partners/fixtures/partners_sample.json` (tanpa pk, timestamp ISO).
- Fixture quotation: `sales/fixtures/sales_quotations_sample.json` (2 contoh: single & multi; lengkap cargo + charges).
- Seeder cepat: `seed_two_quotations.py`.

## ▶️ Perintah sering dipakai
```bash
# load sample partners
python manage.py loaddata partners_sample

# seed 2 quotation contoh via script
python manage.py shell -c "import seed_two_quotations as s; s.run()"

# buka UI
# /sales/quotations/
# /sales/quotations/wizard/v3/start/
# /sales/quotations/<id>/
```

## 🚧 Next
- Business type **Ship Chartering** (model + wizard terpisah).
- **Sales Order** setelah quotation.
- Format angka (IDR) & opsi hide kolom cargo metrics kosong.
- UAT: buat quotation baru → cek detail & PDF.