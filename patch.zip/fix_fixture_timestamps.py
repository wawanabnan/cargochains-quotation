import json, datetime
from pathlib import Path

FIXTURE_IN  = Path("sales/fixtures/freight_demo.json")
FIXTURE_OUT = Path("sales/fixtures/freight_demo_fixed.json")

def iso(dt: datetime.datetime) -> str:
    # naive (tanpa timezone) juga diterima Django: "YYYY-MM-DDTHH:MM:SS"
    return dt.strftime("%Y-%m-%dT%H:%M:%S")

def main():
    if not FIXTURE_IN.exists():
        raise SystemExit(f"Fixture not found: {FIXTURE_IN}")

    data = json.loads(FIXTURE_IN.read_text(encoding="utf-8"))

    base = datetime.datetime(2025, 8, 1, 9, 0, 0)
    out = []
    for obj in data:
        if obj.get("model") == "sales.freightquotation":
            fields = obj.setdefault("fields", {})
            # tambahkan created_at & updated_at bila belum ada
            if "created_at" not in fields:
                # supaya beda-beda, offsetkan sedikit per pk
                pk = obj.get("pk", 0) or 0
                fields["created_at"] = iso(base + datetime.timedelta(minutes=int(pk)))
            if "updated_at" not in fields:
                pk = obj.get("pk", 0) or 0
                fields["updated_at"] = iso(base + datetime.timedelta(minutes=int(pk), seconds=30))
        out.append(obj)

    FIXTURE_OUT.parent.mkdir(parents=True, exist_ok=True)
    FIXTURE_OUT.write_text(json.dumps(out, ensure_ascii=False, indent=2), encoding="utf-8")
    print(f"[ok] Wrote fixed fixture -> {FIXTURE_OUT}")

if __name__ == "__main__":
    main()
