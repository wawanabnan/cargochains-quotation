from pathlib import Path
import textwrap, shutil, datetime, os

ROOT = Path(__file__).resolve().parent
STAMP = datetime.datetime.now().strftime("%Y%m%d-%H%M%S")

def backup(p: Path):
    if p.exists():
        bak = p.with_suffix(p.suffix + f".{STAMP}.bak")
        bak.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(p, bak)
        print(f"[backup] {p} -> {bak.name}")

def write_file(p: Path, content: str):
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(textwrap.dedent(content).lstrip(), encoding="utf-8")
    print(f"[write]  {p}")

# 1) Patch template list.html: tambah checkbox + row-click JS
def patch_list_template():
    p = ROOT / "templates" / "sales" / "freight" / "list.html"
    backup(p)
    html = """
    {% extends "base.html" %}
    {% block title %}Freight Quotations{% endblock %}
    {% block content %}
    <div class="d-flex justify-content-between align-items-center mb-3">
      <h5 class="mb-0">Freight Quotations</h5>
      <a href="{% url 'sales:freight_new' %}" class="btn btn-primary btn-sm rounded-0">Create New</a>
    </div>
    <div class="card shadow-sm border-0">
      <div class="table-responsive">
        <table class="table table-sm align-middle mb-0" id="fq-table">
          <thead class="table-light">
            <tr>
              <th style="width:36px;">
                <input type="checkbox" id="chk-all" class="form-check-input">
              </th>
              <th style="width:80px;">#ID</th>
              <th style="width:140px;">Number</th>
              <th style="width:120px;">Date</th>
              <th>Customer</th>
              <th style="width:110px;">Currency</th>
              <th style="width:110px;">Mode</th>
              <th style="width:160px;">Service</th>
              <th style="width:120px;" class="text-end">Cargo Lines</th>
              <th style="width:110px;"></th>
            </tr>
          </thead>
          <tbody>
            {% for q in quotations %}
            <tr class="row-link" data-href="{% url 'sales:freight_view' q.id %}">
              <td>
                <input type="checkbox" class="row-check form-check-input" value="{{ q.id }}">
              </td>
              <td>{{ q.id }}</td>
              <td>{{ q.number }}</td>
              <td>{{ q.date }}</td>
              <td>{{ q.customer }}</td>
              <td>{{ q.currency }}</td>
              <td>{{ q.transport_mode }}</td>
              <td>{{ q.service_option }}</td>
              <td class="text-end">{{ q.cargos.count }}</td>
              <td class="text-end">
                <a href="{% url 'sales:freight_view' q.id %}" class="btn btn-outline-secondary btn-sm rounded-0">View</a>
              </td>
            </tr>
            {% empty %}
            <tr><td colspan="10" class="text-center text-muted py-4">No quotations found.</td></tr>
            {% endfor %}
          </tbody>
        </table>
      </div>
    </div>
    {% endblock %}

    {% block extra_js %}
    <script>
    (function(){
      const table = document.getElementById('fq-table');
      if(!table) return;

      // Select all checkbox
      const chkAll = document.getElementById('chk-all');
      if(chkAll){
        chkAll.addEventListener('change', function(){
          table.querySelectorAll('tbody .row-check').forEach(ch => { ch.checked = chkAll.checked; });
        });
      }

      // Row click navigation, kecuali klik pada elemen interaktif
      table.querySelectorAll('tbody tr.row-link').forEach(tr => {
        tr.addEventListener('click', function(e){
          const target = e.target;
          // Jangan navigate jika klik pada elemen berikut
          if (target.closest('a, button, input, label, select, textarea')) {
            return;
          }
          const href = tr.getAttribute('data-href');
          if(href){ window.location = href; }
        });
      });
    })();
    </script>
    {% endblock %}
    """
    write_file(p, html)

# 2) Management command: seed_freight_demo (hapus & buat 10 data)
def write_seed_command():
    base = ROOT / "sales" / "management" / "commands"
    base.mkdir(parents=True, exist_ok=True)
    # __init__.py
    for init in [base.parent, base]:
        ip = init / "__init__.py"
        if not ip.exists():
            write_file(ip, "# init")
    cmdp = base / "seed_freight_demo.py"
    backup(cmdp)

    code = r"""
    from django.core.management.base import BaseCommand
    from django.db import transaction
    from django.utils import timezone
    import random

    from sales.models import FreightQuotation, FreightCargo, FreightCharge
    try:
        from partners.models import Partner
    except Exception:
        # fallback sederhana kalau app partners berbeda
        Partner = None

    try:
        from geo.models import Location
    except Exception:
        Location = None

    class Command(BaseCommand):
        help = "Delete all freight quotations and seed 10 demo rows (5 single-destination, 5 multi-destination)."

        def handle(self, *args, **kwargs):
            with transaction.atomic():
                # Hapus data lama
                FreightCharge.objects.all().delete()
                FreightCargo.objects.all().delete()
                FreightQuotation.objects.all().delete()

                # Partner: ambil yang ada / buat dummy
                partner = None
                if Partner:
                    partner = Partner.objects.first()
                    if partner is None:
                        # coba buat partner dummy minimalis
                        try:
                            partner = Partner.objects.create(name="PT. Demo Partner", code="DEMO")
                        except Exception:
                            pass

                today = timezone.localdate()
                modes = [("SEA","DOOR_TO_DOOR"), ("SEA","PORT_TO_PORT"), ("AIR","AIRPORT_TO_AIRPORT"), ("LAND","TRUCKING")]

                # Helper pick location sesuai mode
                def pick_locations(mode):
                    if not Location:
                        return (None, None)
                    qs = Location.objects.all().order_by("?")
                    if mode == "SEA":
                        qs = qs.filter(type__in=[getattr(Location, "SEAPORT", "SEAPORT"), getattr(Location, "JETTY", "JETTY")])
                    elif mode == "AIR":
                        qs = qs.filter(type=getattr(Location, "AIRPORT", "AIRPORT"))
                    else:
                        qs = qs.filter(type__in=[getattr(Location, "CITY", "CITY"), getattr(Location, "JETTY", "JETTY")])
                    origin = qs.first()
                    dest = qs[1] if qs.count() > 1 else origin
                    return (origin, dest)

                # 5 single-destination (1 cargo)
                created = 0
                for i in range(5):
                    mode, service = random.choice(modes)
                    q = FreightQuotation.objects.create(
                        date=today,
                        customer=partner if partner else None,
                        currency="IDR",
                        payment_term="TOP 14 days",
                        transport_mode=mode,
                        service_option=service,
                        notes=f"Demo single cargo {i+1}",
                        multi_destination=False,
                    )
                    o, d = pick_locations(mode)
                    FreightCargo.objects.create(
                        quotation=q,
                        description=f"Commodity S{i+1}",
                        qty=1,
                        weight_kg=100 + i * 10,
                        volume_cbm=5 + i,
                        price=500000,
                        amount=500000,
                        origin=o,
                        destination=d,
                    )
                    created += 1

                # 5 multi-destination (2 cargo)
                for i in range(5):
                    mode, service = random.choice(modes)
                    q = FreightQuotation.objects.create(
                        date=today,
                        customer=partner if partner else None,
                        currency="IDR",
                        payment_term="TOP 30 days",
                        transport_mode=mode,
                        service_option=service,
                        notes=f"Demo multi cargo {i+1}",
                        multi_destination=True,
                    )
                    # cargo 1
                    o1, d1 = pick_locations(mode)
                    FreightCargo.objects.create(
                        quotation=q,
                        description=f"Commodity M{i+1}-1",
                        qty=2,
                        weight_kg=200 + i * 20,
                        volume_cbm=8 + i,
                        price=750000,
                        amount=1500000,
                        origin=o1,
                        destination=d1,
                    )
                    # cargo 2
                    o2, d2 = pick_locations(mode)
                    FreightCargo.objects.create(
                        quotation=q,
                        description=f"Commodity M{i+1}-2",
                        qty=1,
                        weight_kg=120 + i * 12,
                        volume_cbm=4 + i,
                        price=600000,
                        amount=600000,
                        origin=o2,
                        destination=d2,
                    )
                    created += 1

                self.stdout.write(self.style.SUCCESS(f"Seeded {created} FreightQuotation rows (with cargos)."))
    """
    write_file(cmdp, code)

def main():
    patch_list_template()
    write_seed_command()
    print("\n✅ Patch selesai.")
    print("→ Jalankan: python manage.py migrate")
    print("→ Lalu:     python manage.py seed_freight_demo")

if __name__ == "__main__":
    main()
