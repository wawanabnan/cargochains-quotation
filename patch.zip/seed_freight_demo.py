# ... setelah buat FreightCargo untuk single cargo
FreightCharge.objects.create(
    cargo=cargo,  # cargo variabel yang baru dibuat
    description="Handling Fee",
    qty=1,
    rate=100000,
    amount=100000,
)
FreightCharge.objects.create(
    cargo=cargo,
    description="Documentation",
    qty=1,
    rate=50000,
    amount=50000,
)
